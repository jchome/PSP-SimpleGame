def freemem():
  return 0

def realmem():
  return 0

def getbus():
  return 0

def setbus(mhz):
  return 0

def getclock():
  return 0

def setclock(mhz):
  return 0

def battery():
  return [0,0,0,100,0,0,0]

def getnickname():
  return "NickName"

def powertick():
  pass